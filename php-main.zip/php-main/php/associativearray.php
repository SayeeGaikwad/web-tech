<!DOCTYPE html>
<html>
    <head>
        <title>AssociativeArray</title>
    </head>
    <body>
        <h2>Associative Array</h2>
        <?php
        $std=array("Name"=>"Kirti","Occupation"=>"Student","age"=>"21");
        echo "Name:".$std["Name"]."<br/>";
        echo "Occupation:" .$std["Occupation"]."<br/>";
        echo "age:" .$std["age"]."<br/>";
        ?>
    </body>
    </html>
    

