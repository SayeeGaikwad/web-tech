<html>
    <head>
        <title>Datatype Analysis</title>
</head>
<body>
    <?php
    $x=10;
    echo "Data Type of x: ".gettype($x). "<br>";

    $x=10.33;
    echo "Data Type of x now : ".gettype($x)."<br>";
    ?>
</body>
</html>