<!DOCTYPE html>
<html>
<head>
        <title>PHP If Else Example</title>
</head>
<body>
<?php
$number=7;

if($number%2==0){
    echo "<p> The number $number is even.</p>";
}
else{
    echo "<p>The number $number is odd.</p>";
}
?>
</body>
</html>