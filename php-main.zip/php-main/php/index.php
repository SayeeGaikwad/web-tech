<?php

$city = array("Kolhapur", "Mumbai", "Pune");
foreach ($city as $x) {
  echo "$x <br>";
}
?>