<html>
<body>

<form action="welcome.php" method="POST">
Name: <input type="text" name="name"><br>
Website:<input type="text" name="website"><br>
E-mail: <input type="text" name="email"><br>

<input type="submit">
</form>

</body>
</html>